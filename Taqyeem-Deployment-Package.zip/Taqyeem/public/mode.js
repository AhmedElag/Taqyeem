window.TAQYEEM_MODE = 'live';
